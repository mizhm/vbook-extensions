function execute() {
  return Response.success([{ title: "Mới cập nhật", input: "https://manhuarock.net/moi-cap-nhat", script: "gen.js" }]);
}
