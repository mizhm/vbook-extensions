let BASE_URL = "https://truyenfree.org";
try {
  if (CONFIG_URL) {
    BASE_URL = CONFIG_URL;
  }
} catch {}
