let BASE_URL = "https://truyen.now";
try {
  if (CONFIG_URL) {
    BASE_URL = CONFIG_URL;
  }
} catch {}
