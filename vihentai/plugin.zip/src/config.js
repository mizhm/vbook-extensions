let BASE_URL = "https://vi-hentai.org";

try {
	if (CONFIG_URL) {
		BASE_URL = CONFIG_URL;
	}
} catch {}
