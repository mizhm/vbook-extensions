let BASE_URL = "https://fanqienovel.com";
// const API_URL = "https://qkfqapi.vv9v.cn/api";
// const API_URL = "https://bk.yydjtc.cn/api";
const API_URL = "http://47.108.80.161:5005/api";

try {
  if (CONFIG_URL) {
    BASE_URL = CONFIG_URL;
  }
} catch {}
