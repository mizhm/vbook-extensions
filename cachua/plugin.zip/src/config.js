let BASE_URL = "https://fanqienovel.com";
const API_URL = "https://qkfqapi.vv9v.cn/api";

try {
  if (CONFIG_URL) {
    BASE_URL = CONFIG_URL;
  }
} catch {}
