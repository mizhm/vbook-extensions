let BASE_URL = "https://fanqienovel.com";
const API_URL = "http://113.45.229.86:8543";

try {
	if (CONFIG_URL) {
		BASE_URL = CONFIG_URL;
	}
} catch {}
