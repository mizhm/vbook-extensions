let BASE_URL = "https://hitomi.la";
let API_DOMAIN = "https://ltn.gold-usergeneratedcontent.net";
let API_DOMAIN2 = "https://atn.gold-usergeneratedcontent.net";

try {
  if (CONFIG_URL) {
    BASE_URL = CONFIG_URL;
  }
} catch {}
