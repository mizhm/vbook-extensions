load("config.js");

function execute() {
	const genres = fetch(`${BASE_URL}/api/types/genres`).json();
	const literaryStyles = fetch(`${BASE_URL}/api/types/literary-styles`).json();
	const worldSettings = fetch(`${BASE_URL}/api/types/world-settings`).json();
	const characterPersonalities = fetch(
		`${BASE_URL}/api/types/character-personalities`,
	).json();

	if (!genres || !literaryStyles || !worldSettings || !characterPersonalities) {
		return Response.error("Failed to fetch genre data");
	}

	const data = [];

	for (const genre of genres) {
		data.push({
			title: genre.name,
			input: `${BASE_URL}/api/novels/?genres=${genre.slug}`,
			script: "genre-content.js",
		});
	}

	for (const genre of literaryStyles) {
		data.push({
			title: genre.name,
			input: `${BASE_URL}/api/novels/?literary_styles=${genre.slug}`,
			script: "genre-content.js",
		});
	}

	for (const genre of worldSettings) {
		data.push({
			title: genre.name,
			input: `${BASE_URL}/api/novels/?world_settings=${genre.slug}`,
			script: "genre-content.js",
		});
	}

	for (const genre of characterPersonalities) {
		data.push({
			title: genre.name,
			input: `${BASE_URL}/api/novels/?character_personalities=${genre.slug}`,
			script: "genre-content.js",
		});
	}

	return Response.success(data);
}
