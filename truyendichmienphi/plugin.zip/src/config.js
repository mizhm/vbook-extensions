let BASE_URL = "https://truyendichmienphi.com";
let API_URL = "https://api.truyendichmienphi.com";

try {
	if (CONFIG_URL) {
		BASE_URL = CONFIG_URL;
	}
} catch {}
