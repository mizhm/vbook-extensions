function execute(url) {
  return Response.success([{ name, url, host }]);
}
