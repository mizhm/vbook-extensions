let BASE_URL = "https://vozer.io";
try {
  if (CONFIG_URL) {
    BASE_URL = CONFIG_URL;
  }
} catch (error) { }
