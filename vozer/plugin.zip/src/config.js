let BASE_URL = "https://metruyencv.biz";
try {
  if (CONFIG_URL) {
    BASE_URL = CONFIG_URL;
  }
} catch (error) {}
